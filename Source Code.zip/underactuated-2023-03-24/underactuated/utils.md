# `underactuated.utils`

```{eval-rst}
.. automodule:: underactuated.utils
   :members:
