# `underactuated.plot_utils`

```{eval-rst}
.. automodule:: underactuated.plot_utils
   :members:
