# `underactuated.multibody`

```{eval-rst}
.. automodule:: underactuated.multibody
   :members:
