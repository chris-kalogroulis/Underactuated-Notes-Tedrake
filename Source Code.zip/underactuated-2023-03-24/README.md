<!-- Remember, this produces the front page on github, dockerhub, and pypi. -->

# Underactuated Robotics

*Algorithms for Walking, Running, Swimming, Flying, and Manipulation*

This is the companion software for the textbook available at:
https://underactuated.csail.mit.edu/

To cite this software (or the corresponding textbook), please use:

Russ Tedrake. _Underactuated Robotics: Algorithms for Walking, Running,
Swimming, Flying, and Manipulation (Course Notes for MIT 6.832)._
Downloaded on [date] from <https://underactuated.csail.mit.edu/>.
